from setuptools import setup
setup(name='ExceptionHandler',
      version='0.1',
      description='Exception Handler',
      url='https://github.com/mirbahar/pyException-handler',
      author='Mirbahar Nurul Amin',
      author_email='rahat.bubt@gmail.com',
      license='None',
      packages=['ExceptionHandler'])
